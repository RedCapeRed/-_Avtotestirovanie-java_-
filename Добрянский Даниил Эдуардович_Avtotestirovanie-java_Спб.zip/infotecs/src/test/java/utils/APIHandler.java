package utils;

import io.qameta.allure.Step;
import io.restassured.response.Response;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import tests.Const;

import static tests.Const.JSON_TEST_DATA_PATH;
import static utils.ParsingJSON.getParamJSON;
import static utils.RequestHandler.*;

public class APIHandler {

    @Step("Создание пользователя")
    public static Long createUser(){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name", getParamJSON(Const.TEST_USER_NAME_KEY, null, JSON_TEST_DATA_PATH));
        jsonObject.put(Const.JOB_FOR_CREATE, getParamJSON(Const.JOB_FOR_CREATE, null, JSON_TEST_DATA_PATH));
        String responseJSON = sendPostRequest(String.valueOf(getParamJSON(Const.CRUD_URL_KEY, null, JSON_TEST_DATA_PATH)),
                jsonObject);
        Long userID = Long.parseLong((String) getParamJSON("id", responseJSON, null));

        return userID;
    }

    @Step("Обновление работы пользователя")
    public static Response updateUser(Long userID){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name", getParamJSON(Const.TEST_USER_NAME_KEY, null, JSON_TEST_DATA_PATH));
        jsonObject.put("job", getParamJSON(Const.JOB_FOR_UPDATE, null, JSON_TEST_DATA_PATH));
        return sendPutRequest(String.valueOf(getParamJSON(Const.CRUD_URL_KEY,
                null, JSON_TEST_DATA_PATH) + "/" + userID), jsonObject);
    }

    @Step("Удаление пользователя")
    public static Response deleteUser(Long userID){
        return sendDeleteRequest(String.valueOf(getParamJSON(Const.CRUD_URL_KEY,
                null, JSON_TEST_DATA_PATH) + "/" + userID));

    }

    @Step("Получение списка пользователей")
    public static JSONArray getAllUsers(){
        JSONArray listUsers = sendGetAllUsersRequest(String.valueOf(getParamJSON(Const.GET_USERS_LIST_KEY, null, JSON_TEST_DATA_PATH)));
        return listUsers;
    }

}
