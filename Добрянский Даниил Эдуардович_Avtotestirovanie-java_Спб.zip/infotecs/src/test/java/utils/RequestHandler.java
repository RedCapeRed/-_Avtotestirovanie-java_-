package utils;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import static utils.ParsingJSON.getParamJSON;


public class RequestHandler {

    public static String sendPostRequest(String url, JSONObject requestBody) {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(requestBody.toString());
        Response response = request.post(url);
        String responseJSON = response.asString();
        return responseJSON;
    }

    public static JSONArray sendGetAllUsersRequest(String url) {
        int numberPage = 1;
        JSONArray allUsers = new JSONArray();

        while (true){
            RequestSpecification request = RestAssured.given();
            Response response = request.get(url + String.valueOf(numberPage));
            String responseJSON = response.asString();
            JSONArray currentUsers = (JSONArray) getParamJSON("data", responseJSON, null);

            if(currentUsers.size() == 0)
                break;

            allUsers.addAll(currentUsers);
            numberPage++;
            }
            return allUsers;
    }

    public static Response sendPutRequest(String url, JSONObject requestBody) {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(requestBody.toString());
        Response response = request.put(url);
        return response;
    }

    public static Response sendDeleteRequest(String url) {
        RequestSpecification request = RestAssured.given();
        Response response = request.delete(url);
        return response;
    }
}
