package utils;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;

public class ParsingJSON {

    public static Object getParamJSON(String param, String JSONString, String JSONFilePath) {
        try {
            JSONParser parser = new JSONParser();
            JSONObject object = JSONString == null ?
                    (JSONObject) parser.parse(new FileReader(JSONFilePath)) :
                    (JSONObject) parser.parse(JSONString);
            Object o = object.get(param);
            return o;
        } catch (IOException ioException) {
            ioException.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
}
