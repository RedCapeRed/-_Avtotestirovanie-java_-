package tests;

import io.qameta.allure.Feature;
import io.qameta.allure.Owner;
import io.qameta.allure.Step;
import io.restassured.response.Response;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;



import static tests.Const.*;
import static utils.APIHandler.*;
import static utils.ParsingJSON.getParamJSON;

@Feature("Тест на создание/изменения/удаления пользователя")
public class TestAPI {

    @Test
    @Owner(value = "Добрянский Даниил Эдуардович")
    public void testCRUDUser() {
        Long userID = createUser();
        JSONArray users = getAllUsers();
        checkContainsUser(userID, users);
        Assert.assertTrue(checkContainsUser(userID, users));

        Response responseForUpdate = updateUser(userID);
        Assert.assertEquals(responseForUpdate.getStatusCode(), OK);
        Assert.assertEquals(getParamJSON("job", responseForUpdate.asString(), null),
                            getParamJSON(Const.JOB_FOR_UPDATE, null, JSON_TEST_DATA_PATH));

        Response responseForDelete = deleteUser(userID);
        Assert.assertEquals(responseForDelete.getStatusCode(), DELETED);

    }

    @Step("Проверка создания нового пользователя")
    public boolean checkContainsUser(Long userID, JSONArray users){
        int createdUsers = 0;
        for(Object o : users){
            JSONObject object = (JSONObject) o;
            if(object.get("id") == userID)
                createdUsers ++;
        }
        return createdUsers == 1;
    }
}
