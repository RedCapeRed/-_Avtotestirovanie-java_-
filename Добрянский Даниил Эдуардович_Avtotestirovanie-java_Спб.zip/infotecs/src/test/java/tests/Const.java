package tests;

public class Const {
    //=====================================KEYS============================================//
    public static final String TEST_USER_NAME_KEY = "name_test_user";

    public static final String JOB_FOR_CREATE = "job_for_create";
    public static final String JOB_FOR_UPDATE = "job_for_update";

    public static final String CRUD_URL_KEY = "crud_user_url";
    public static final String GET_USERS_LIST_KEY = "get_users_list_url";


    //====================================PATHS===========================================//
    public static final String JSON_TEST_DATA_PATH = "src\\test\\java\\tests\\testData.json";

    //===================================STATUS CODE======================================//
    public static final int OK = 200;
    public static final int CREATED = 201;
    public static final int DELETED = 204;

}